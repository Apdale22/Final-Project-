# Bag Shop

![bagshop_git](https://user-images.githubusercontent.com/27451718/86301182-89a8e280-bbdb-11ea-8412-871e61d3a22b.png)

A new Flutter project.

- [Design Credit](https://dribbble.com/shots/10812833-Bag-Shop-Free-Figma-File)

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


<!-- 
ID: C119586
NAME : Abdullahi Abdiwali Hssan -->