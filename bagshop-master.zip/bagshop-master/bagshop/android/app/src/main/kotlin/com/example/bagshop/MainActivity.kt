package com.example.bagshop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
